-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `access`;
CREATE TABLE `access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `url` varchar(255) NOT NULL COMMENT 'URL',
  `clans` text NOT NULL COMMENT 'Кланы',
  `roles` text NOT NULL COMMENT 'Доступ разрешен',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Доступ к страницам';


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `cluster` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru' COMMENT 'Кластер',
  `nickname` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата создания аккаунта',
  `updated_at` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата обновления информации',
  `visited_at` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата посещения сайта',
  `teamspeak_at` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата посещения TS',
  `clan_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ID клана',
  `clan_abbreviation` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Тег клана',
  `clan_name` varchar(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT 'Название клана',
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Должность',
  `role_i18n` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Локализованная должность',
  `since` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата вступления в клан',
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'IP',
  `region` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Регион',
  `avatar` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'Аватарка',
  `email` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'E-mail',
  `skype` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'Skype',
  `tel` varchar(12) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'Телефон',
  `name` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'Реальное имя',
  `city` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'Город',
  `signature` text CHARACTER SET utf8 NOT NULL COMMENT 'Подпись для форума',
  `about` text CHARACTER SET utf8 NOT NULL COMMENT 'О себе',
  `banned` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Забанен',
  PRIMARY KEY (`id`),
  KEY `clan_id` (`clan_id`),
  KEY `nickname` (`nickname`(5)),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Игроки';


DROP TABLE IF EXISTS `accounts_roles`;
CREATE TABLE `accounts_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `role_id` int(11) NOT NULL COMMENT 'Роль',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Связь аккаунтов и ролей';


DROP TABLE IF EXISTS `accounts_sort`;
CREATE TABLE `accounts_sort` (
  `role_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `accounts_sort` (`role_name`, `role_order`) VALUES
('combat_officer',	30),
('commander',	0),
('executive_officer',	10),
('intelligence_officer',	35),
('junior_officer',	40),
('personnel_officer',	20),
('private',	80),
('quartermaster',	36),
('recruit',	90),
('recruitment_officer',	37),
('reservist',	100);

DROP TABLE IF EXISTS `achievements`;
CREATE TABLE `achievements` (
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `condition` text NOT NULL COMMENT 'Условие',
  `description` text NOT NULL COMMENT 'Описание достижения',
  `hero_info` text NOT NULL COMMENT 'Историческая справка',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT 'Изображение',
  `image_big` varchar(255) NOT NULL DEFAULT '' COMMENT 'Изображение 180x180px',
  `name_i18n` varchar(255) NOT NULL DEFAULT '' COMMENT 'Локализованное поле name',
  `order` int(11) NOT NULL COMMENT 'Порядок отображения достижения',
  `section` varchar(255) NOT NULL DEFAULT '' COMMENT 'Раздел',
  `section_i18n` varchar(255) NOT NULL DEFAULT '' COMMENT 'Локализованное название раздела',
  `section_order` int(11) NOT NULL COMMENT 'Порядок отображения раздела',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT 'Тип',
  `options` text NOT NULL COMMENT 'Достижения',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Достижения';


DROP TABLE IF EXISTS `bans`;
CREATE TABLE `bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `time` int(10) unsigned NOT NULL COMMENT 'Забанен',
  `expire` int(10) unsigned NOT NULL COMMENT 'Срок',
  `author_id` bigint(20) NOT NULL COMMENT 'Выдал',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `author_id` (`author_id`),
  KEY `site_id_account_id` (`site_id`,`account_id`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Банлист';


DROP TABLE IF EXISTS `battles`;
CREATE TABLE `battles` (
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  `provinces` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Провинции',
  `started` int(1) NOT NULL COMMENT 'Бой начался',
  `time` int(11) NOT NULL COMMENT 'Время',
  `arenas` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Игровые карты',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тип'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Бои';


DROP TABLE IF EXISTS `clans`;
CREATE TABLE `clans` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `cluster` varchar(64) NOT NULL DEFAULT 'ru' COMMENT 'Кластер',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `abbreviation` varchar(5) NOT NULL COMMENT 'Тег',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `parser_info_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки информации',
  `parser_accounts_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки аккаунтов',
  `parser_tanks_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки танков',
  `parser_battles_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки боев',
  `parser_provinces_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки провинций',
  `parser_ivanerr_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки Иванерра',
  `parser_teamspeak_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки ТС',
  `ivanerr_rating` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Рейтинг по Иванерру',
  `ivanerr_power` float(5,1) NOT NULL DEFAULT '0.0' COMMENT 'Сила по Иванерру',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  `parser_famepoints_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата загрузки очков славы',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `parser_info_time` (`parser_info_time`),
  KEY `parser_accounts_time` (`parser_accounts_time`),
  KEY `parser_tanks_time` (`parser_tanks_time`),
  KEY `order` (`order`),
  KEY `cluster` (`cluster`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Кланы';


DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  `accounts` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Состав',
  PRIMARY KEY (`id`),
  KEY `clan_id` (`clan_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `value` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Значение',
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Категория',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text' COMMENT 'Тип данных',
  `items` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Возможные значения',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `name` (`name`(5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Конфигурация';


DROP TABLE IF EXISTS `costs`;
CREATE TABLE `costs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `item_id` int(10) unsigned NOT NULL COMMENT 'Услуга',
  `amount` float(8,2) unsigned NOT NULL COMMENT 'Стоимость',
  `time` int(10) unsigned NOT NULL COMMENT 'Дата',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Списание средств';


DROP TABLE IF EXISTS `customs`;
CREATE TABLE `customs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `text1` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `text2` mediumtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML код',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `account_id` (`account_id`),
  KEY `name` (`name`(5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Произвольные страницы';


DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  `type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Тип',
  `event` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Событие',
  `time` int(11) NOT NULL COMMENT 'Время',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `clan_id_type` (`clan_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='События';


DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `name` varchar(64) NOT NULL COMMENT 'Название',
  `size` int(11) unsigned NOT NULL COMMENT 'Размер',
  `time` int(10) unsigned NOT NULL COMMENT 'Дата',
  `md5` varchar(32) NOT NULL COMMENT 'MD5',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `name` (`name`(5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Файлы';


DROP TABLE IF EXISTS `forum_categories`;
CREATE TABLE `forum_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `group_id` int(11) unsigned NOT NULL COMMENT 'ID группы',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  `file_allow` int(1) NOT NULL DEFAULT '0' COMMENT 'Разрешить прикреплять файлы',
  `file_ext` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Допустимые расширения файлов',
  `file_size` int(11) NOT NULL DEFAULT '0' COMMENT 'Максимальный размер файла (Кб)',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Категории форума';


DROP TABLE IF EXISTS `forum_files`;
CREATE TABLE `forum_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `message_id` int(11) unsigned NOT NULL COMMENT 'ID сообщения',
  `file` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Файл',
  `time` int(11) unsigned NOT NULL COMMENT 'Время',
  `size` int(11) unsigned NOT NULL COMMENT 'Размер',
  PRIMARY KEY (`id`),
  KEY `message_id` (`message_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Файлы форума';


DROP TABLE IF EXISTS `forum_groups`;
CREATE TABLE `forum_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Категории форума';


DROP TABLE IF EXISTS `forum_messages`;
CREATE TABLE `forum_messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `category_id` int(11) unsigned NOT NULL COMMENT 'ID категории',
  `theme_id` int(11) unsigned NOT NULL COMMENT 'ID темы',
  `account_id` bigint(20) NOT NULL COMMENT 'ID аккаунта',
  `message` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Сообщение',
  `time` int(11) unsigned NOT NULL COMMENT 'Время',
  `updated_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Время изменения',
  `updated_account_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'ID изменившего аккаунта',
  PRIMARY KEY (`id`),
  KEY `theme_id` (`theme_id`),
  KEY `account_id` (`account_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Сообщения форума';


DROP TABLE IF EXISTS `forum_themes`;
CREATE TABLE `forum_themes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `category_id` int(11) unsigned NOT NULL COMMENT 'ID категории',
  `account_id` bigint(20) NOT NULL COMMENT 'ID аккаунта',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `time` int(11) unsigned NOT NULL COMMENT 'Время',
  `fixed` int(1) NOT NULL DEFAULT '0' COMMENT 'Прикреплена',
  `closed` int(1) NOT NULL DEFAULT '0' COMMENT 'Закрыта',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `category_id` (`category_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Темы форума';


DROP TABLE IF EXISTS `fronts`;
CREATE TABLE `fronts` (
  `id` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ID',
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `is_active` int(1) NOT NULL COMMENT 'Активность',
  `is_event` int(1) NOT NULL COMMENT 'Обычная карта или карта события',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Фронты';


DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  `category_id` int(10) unsigned NOT NULL COMMENT 'Категория',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Адрес',
  `time` int(10) unsigned NOT NULL COMMENT 'Дата добавления',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `account_id` (`account_id`),
  KEY `category_id` (`category_id`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Контент галереи';


DROP TABLE IF EXISTS `gallery_categories`;
CREATE TABLE `gallery_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `type` int(1) unsigned NOT NULL COMMENT 'Тип',
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Категории галереи';


DROP TABLE IF EXISTS `ivanerr`;
CREATE TABLE `ivanerr` (
  `clan_id` bigint(20) unsigned NOT NULL COMMENT 'ID клана',
  `abbreviation` varchar(10) NOT NULL COMMENT 'Тэг',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `power` int(11) NOT NULL COMMENT 'Сила',
  `om` int(11) NOT NULL COMMENT 'Огн. мощь',
  `skill` int(11) NOT NULL COMMENT 'Скилл',
  `calc_power` float(10,4) NOT NULL COMMENT 'Расчетная сила',
  UNIQUE KEY `clan_id` (`clan_id`),
  KEY `power` (`power`),
  KEY `calc_power` (`calc_power`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Иванерр';


DROP TABLE IF EXISTS `maps`;
CREATE TABLE `maps` (
  `id` varchar(64) NOT NULL COMMENT 'ID',
  `type` varchar(64) NOT NULL COMMENT 'Тип карты',
  `state` varchar(64) NOT NULL COMMENT 'Состояние карты',
  `map_url` varchar(64) NOT NULL COMMENT 'URL карты на сайте',
  `season_info` text NOT NULL COMMENT 'Информация о последнем сезоне',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Карты';

INSERT INTO `maps` (`id`, `type`, `state`, `map_url`, `season_info`) VALUES
('eventmap',	'event',	'freezed',	'http://worldoftanks.ru/clanwars/maps/eventmap',	'null'),
('globalmap',	'normal',	'unavailable',	'http://worldoftanks.ru/clanwars/maps/globalmap',	'{\"status\":\"finished\",\"name_i18n\":\"\\u041f\\u0435\\u0440\\u0432\\u0430\\u044f \\u043a\\u0430\\u043c\\u043f\\u0430\\u043d\\u0438\\u044f\",\"start_at\":1380348003,\"finish_at\":1384146003,\"steps\":[{\"status\":\"finished\",\"name_i18n\":\"\\u041f\\u043e\\u0434\\u0433\\u043e\\u0442\\u043e\\u0432\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"start_at\":1380348003,\"number\":0,\"finish_at\":1380430803},{\"status\":\"finished\",\"name_i18n\":\"\\u0421\\u043e\\u0431\\u0438\\u0440\\u0430\\u0442\\u0430\\u0435\\u043b\\u044c \\u0437\\u0435\\u043c\\u0435\\u043b\\u044c\",\"start_at\":1380430803,\"number\":1,\"finish_at\":1381294803},{\"status\":\"finished\",\"name_i18n\":\"\\u0412\\u0435\\u043b\\u0438\\u043a\\u0430\\u044f \\u0434\\u0435\\u043f\\u0440\\u0435\\u0441\\u0441\\u0438\\u044f\",\"start_at\":1381294803,\"number\":2,\"finish_at\":1382245203},{\"status\":\"finished\",\"name_i18n\":\"\\u042d\\u043f\\u043e\\u0445\\u0430 \\u0440\\u0435\\u0432\\u043e\\u043b\\u044e\\u0446\\u0438\\u0439\",\"start_at\":1382245203,\"number\":3,\"finish_at\":1383195603},{\"status\":\"finished\",\"name_i18n\":\"\\u041c\\u0438\\u0440\\u043e\\u0432\\u043e\\u0435 \\u0433\\u043e\\u0441\\u043f\\u043e\\u0434\\u0441\\u0442\\u0432\\u043e\",\"start_at\":1383195603,\"number\":4,\"finish_at\":1384146003}]}');

DROP TABLE IF EXISTS `menu_left`;
CREATE TABLE `menu_left` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `label` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'URL',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  `highlight` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Подразделы',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Верхнее меню';


DROP TABLE IF EXISTS `menu_top`;
CREATE TABLE `menu_top` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `label` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'URL',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  `highlight` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Подразделы',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Верхнее меню';


DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тема',
  `object_id` int(11) NOT NULL COMMENT 'ID объекта',
  `time` int(11) NOT NULL COMMENT 'Дата',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `message` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Сообщение',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `name_object_id` (`name`,`object_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Сообщения';


DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `time` int(11) NOT NULL COMMENT 'Время добавления',
  `text1` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `text2` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Краткий текст',
  `text3` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Полный текст',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  `category_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Категория',
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Картинка',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `time` (`time`),
  KEY `site_id` (`site_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Новости';


DROP TABLE IF EXISTS `news_categories`;
CREATE TABLE `news_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `enabled` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Включена',
  `edit` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Разрешено редактировать',
  `on_main` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Показывать новости из этой категории на главной',
  `on_title` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Показывать название рубрики в заголовке новостей',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Рубрики новостей';


DROP TABLE IF EXISTS `notices`;
CREATE TABLE `notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  `time` int(11) NOT NULL COMMENT 'Дата создания',
  `expire` int(11) NOT NULL COMMENT 'Актуальность',
  `notice` text NOT NULL COMMENT 'Уведомление',
  `clans` text NOT NULL COMMENT 'Кланы',
  `recipients` text NOT NULL COMMENT 'Получатели',
  `answers` text NOT NULL COMMENT 'Варианты ответа',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `site_id` (`site_id`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Уведомления';


DROP TABLE IF EXISTS `notices_all`;
CREATE TABLE `notices_all` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `time` int(11) unsigned NOT NULL COMMENT 'Дата создания',
  `notice` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Уведомление',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Уведомления для всех';


DROP TABLE IF EXISTS `notices_recipients`;
CREATE TABLE `notices_recipients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `notices_id` int(11) NOT NULL COMMENT 'Уведомление',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `answer` int(1) NOT NULL DEFAULT '0' COMMENT 'Ответ',
  PRIMARY KEY (`id`),
  KEY `notices_id` (`notices_id`),
  KEY `site_id` (`site_id`),
  KEY `account_id_answer` (`account_id`,`answer`),
  KEY `account_id` (`account_id`),
  KEY `answer` (`answer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Получатели уведомлений';


DROP TABLE IF EXISTS `online`;
CREATE TABLE `online` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `time` int(11) NOT NULL COMMENT 'Дата',
  `battles_all` int(11) NOT NULL COMMENT 'Все бои',
  `battles_clan` int(11) NOT NULL COMMENT 'Бои в составе клана',
  `battles_company` int(11) NOT NULL COMMENT 'Ротные бои',
  `battles_team` int(11) NOT NULL COMMENT 'Командные бои',
  `battles_stronghold_defense` int(11) NOT NULL COMMENT 'Оборона укрепрайона',
  `battles_stronghold_skirmish` int(11) NOT NULL COMMENT 'Вылазки',
  `battles_globalmap_absolute` int(11) NOT NULL COMMENT 'ГК Абсолютный дивизион',
  `battles_globalmap_champion` int(11) NOT NULL COMMENT 'ГК Чемпионский девизион',
  `battles_globalmap_middle` int(11) NOT NULL COMMENT 'ГК Средний дивизион',
  `battles_random` int(11) NOT NULL COMMENT 'Случайные бои',
  `resources` int(11) NOT NULL COMMENT 'Промресурсы',
  `wn8` float(6,2) NOT NULL COMMENT 'WN8',
  `wins` float(5,2) NOT NULL COMMENT 'Процент побед',
  `globalmap_wins` int(11) NOT NULL COMMENT 'Победы на ГК',
  `gold` float(5,2) NOT NULL COMMENT 'Начислено золота',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `clan_id` (`clan_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Онлайн';


DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `item_id` int(10) unsigned NOT NULL COMMENT 'Услуга',
  `amount` float(8,2) unsigned NOT NULL COMMENT 'Стоимость',
  `m_operation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Внутренний номер платежа',
  `m_operation_ps` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Способ оплаты',
  `m_operation_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Дата и время формирования операции',
  `m_operation_pay_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Дата и время выполнения платежа',
  `m_curr` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Валюта платежа',
  `m_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Статус платежа',
  `m_sign` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Электронная подпись',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `m_status` (`m_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Заказы';


DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `text1` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Заголовок',
  `text2` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Текст страницы',
  `time` int(11) NOT NULL COMMENT 'Время добавления',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `site_id` (`site_id`),
  KEY `name` (`name`(5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Страницы';


DROP TABLE IF EXISTS `parser_queue`;
CREATE TABLE `parser_queue` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `queue` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Очередь',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Очередь парсера';


DROP TABLE IF EXISTS `pmsg`;
CREATE TABLE `pmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `talk_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `talker_id` bigint(20) NOT NULL,
  `msg_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `talk_hash` (`talk_hash`,`msg_time`),
  KEY `talker_id` (`talker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `pmsg_cc`;
CREATE TABLE `pmsg_cc` (
  `talk_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `last_visit` timestamp NOT NULL DEFAULT '1988-05-26 11:00:00',
  PRIMARY KEY (`talk_hash`,`account_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `pmsg_thumbs`;
CREATE TABLE `pmsg_thumbs` (
  `account_id` bigint(20) NOT NULL,
  `talk_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`account_id`,`talk_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `polls`;
CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Автор',
  `time` int(10) unsigned NOT NULL COMMENT 'Дата создания',
  `enabled` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Принимать ответы',
  `access` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Могут голосовать',
  `question` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Вопрос',
  `answer1` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ответ 1',
  `answer2` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ответ 2',
  `answer3` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 3',
  `answer4` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 4',
  `answer5` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 5',
  `answer6` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 6',
  `answer7` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 7',
  `answer8` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 8',
  `answer9` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 9',
  `answer10` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ответ 10',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Опросы';


DROP TABLE IF EXISTS `polls_answers`;
CREATE TABLE `polls_answers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `poll_id` int(10) unsigned NOT NULL COMMENT 'Опрос',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `answer` int(10) unsigned NOT NULL COMMENT 'Ответ',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `poll_id` (`poll_id`),
  KEY `account_id` (`account_id`),
  KEY `answer` (`answer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `provinces`;
CREATE TABLE `provinces` (
  `id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ID',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `arena_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Карта',
  `prime_time` int(11) NOT NULL COMMENT 'Прайм',
  `attacked` int(1) NOT NULL COMMENT 'Атакована',
  `revenue` int(11) NOT NULL COMMENT 'Доход',
  `occupancy_time` int(11) NOT NULL COMMENT 'Время владения',
  `combats_running` int(1) NOT NULL COMMENT 'Идут бои',
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  PRIMARY KEY (`id`),
  KEY `clan_id` (`clan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Провинции';


DROP TABLE IF EXISTS `provinces2`;
CREATE TABLE `provinces2` (
  `id` varchar(64) NOT NULL COMMENT 'ID',
  `arena_i18n` varchar(255) NOT NULL COMMENT 'Название карты',
  `arena_id` varchar(255) NOT NULL COMMENT 'Идентификатор карты',
  `clan_id` bigint(20) NOT NULL COMMENT 'Владелец провинции',
  `map_id` varchar(64) NOT NULL COMMENT 'Идентификатор Глобальной карты',
  `neighbors` text NOT NULL COMMENT 'Соседние провинции',
  `primary_region` varchar(255) NOT NULL COMMENT 'Основной регион',
  `prime_time` int(11) NOT NULL COMMENT 'Прайм-тайм',
  `province_i18n` varchar(255) NOT NULL COMMENT 'Название провинции',
  `revenue` int(11) NOT NULL COMMENT 'Суточный доход с провинции',
  `status` varchar(255) NOT NULL COMMENT 'Вид провинции',
  `updated_at` int(11) NOT NULL COMMENT 'Дата обновления информации о провинциях на карте',
  `vehicle_max_level` int(11) NOT NULL COMMENT 'Максимальный уровень техники',
  `regions` text NOT NULL COMMENT 'Регионы',
  PRIMARY KEY (`id`),
  KEY `map_id` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Провинции';


DROP TABLE IF EXISTS `recruitment`;
CREATE TABLE `recruitment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Сайт',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `clan_id` int(11) NOT NULL COMMENT 'Клан',
  `time` int(11) NOT NULL COMMENT 'Дата заявки',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT 'Статус',
  `resolution` int(1) NOT NULL DEFAULT '0' COMMENT 'Решение о приеме',
  `resolution_account` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Решение принял',
  `resolution_time` int(11) NOT NULL DEFAULT '0' COMMENT 'Дата приема',
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя',
  `age` int(11) NOT NULL COMMENT 'Возраст',
  `about` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'О себе',
  `experience` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Нет' COMMENT 'Опыт командования',
  `invited` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Приглашен в',
  `battles` int(11) NOT NULL COMMENT 'Бои',
  `wins` int(3) NOT NULL COMMENT '%',
  `re` int(4) NOT NULL COMMENT 'РЭ',
  `wn8` int(4) NOT NULL COMMENT 'WN8',
  `bs` int(5) NOT NULL COMMENT 'БС',
  `t10` int(4) NOT NULL COMMENT 'Т',
  PRIMARY KEY (`id`),
  KEY `resolution_account` (`resolution_account`),
  KEY `account_id` (`account_id`),
  KEY `clan_id` (`clan_id`),
  KEY `status_id` (`status`,`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Военкомат';


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Роли';

INSERT INTO `roles` (`id`, `name`, `description`, `order`) VALUES
(1,	'Администратор сайта',	'Администратор сайта имеет права владельца сайта, кроме возможности удаления сайта',	-10),
(2,	'Редактор новостей',	'Редактор новостей может создавать, редактировать, удалять новости, опросы и уведомления',	0),
(3,	'Редактор страниц',	'Редактор страниц может создавать, редактировать, удалять статические страницы',	0),
(4,	'Кадровик',	'Кадровик может принимать решения в военкомате и просматривать статистику произвольного игрока',	-1),
(5,	'Редактор кланов',	'Редактор кланов может создавать, удалять кланы',	0),
(8,	'Модератор',	'Модератор имеет права администратора сайта, кроме возможности назначения ролей',	-9);

DROP TABLE IF EXISTS `sites`;
CREATE TABLE `sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `cluster` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru' COMMENT 'Кластер',
  `language` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru' COMMENT 'Язык сайта',
  `url` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'URL',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  `time_created` int(11) NOT NULL COMMENT 'Дата создания',
  `time_modified` int(11) NOT NULL COMMENT 'Дата изменения',
  `style_id` int(11) unsigned NOT NULL COMMENT 'Тема оформления',
  `css` mediumtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'CSS',
  `css_disabled` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'CSS отключен',
  `premium_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Окончание премиум аккаунта',
  `banned` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Забанен',
  `premium_reklama` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Реклама отключена',
  `premium_clans` int(11) unsigned NOT NULL DEFAULT '3' COMMENT 'Ограничение количества кланов',
  `premium_domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Не подключен' COMMENT 'Срок действия домена',
  `premium_html` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Редактирование HTML',
  `header` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML шапки',
  `footer` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML подвала',
  `sidebar` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML боковой колонки',
  `index` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML главной',
  `news` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML страницы новостей',
  `favicon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Ссылка на favicon',
  `check` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Проверка наличия ссылок',
  `check_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата проверки ссылок',
  `premium_companies` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Роты подключены',
  `premium_widgets` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '[]' COMMENT 'Активированные виджеты',
  `premium_replays` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Реплеи подключены',
  `premium_tactic` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Тактический планшет подключен',
  `premium_gallery` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Галерея подключена',
  `check_life_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата проверки активности сайта',
  `reset` int(1) NOT NULL DEFAULT '0' COMMENT 'Сброс',
  `balance` float(8,2) NOT NULL DEFAULT '0.00' COMMENT 'Баланс',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_id` (`account_id`),
  UNIQUE KEY `url` (`url`),
  KEY `style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Сайты';


DROP TABLE IF EXISTS `styles`;
CREATE TABLE `styles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `css` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'CSS',
  `theme` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тема',
  `skin` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Скин',
  `header` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML шапки',
  `footer` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML подвала',
  `sidebar` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML колонки',
  `index` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML главной',
  `enabled` int(1) NOT NULL DEFAULT '0' COMMENT 'Активность',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Темы оформления';

INSERT INTO `styles` (`id`, `name`, `css`, `theme`, `skin`, `header`, `footer`, `sidebar`, `index`, `enabled`, `order`) VALUES
(1,	'Vinous',	'/*------------------------------------------\n	Сброс стилей\n------------------------------------------*/\n\nhtml, body, div, span, applet, object, iframe,\nh1, h2, h3, h4, h5, h6, p, blockquote, pre,\na, abbr, acronym, address, big, cite, code,\ndel, dfn, em, font, img, ins, kbd, q, s, samp,\nsmall, strike, strong, sub, sup, tt, var,\nb, u, i, center,\ndl, dt, dd, ol, ul, li,\nfieldset, form, label, legend,\ntable, caption, tbody, tfoot, thead, tr, th, td {\n	margin: 0;\n	padding: 0;\n	border: 0;\n	outline: 0;\n	font-size: 100%;\n	vertical-align: top;\n	background: transparent;\n}\nbody {\n	line-height: 1.3;\n}\nol, ul {\n	list-style: none;\n}\nblockquote, q {\n	quotes: none;\n}\n:focus {\n	outline: 0;\n}\nins {\n	text-decoration: none;\n}\ndel {\n	text-decoration: line-through;\n}\ntable {\n	border-collapse: collapse;\n	border-spacing: 0;\n}\nimg {max-width: 100%;}\n\n/*------------------------------------------\n	Общие стили\n------------------------------------------*/\n\nbody {\n	background: #000 url(\'../images/bg.jpg\') center top no-repeat;\n	font-family: arial;\n	font-size: 12px;\n	color: #979899;\n}\ndiv, h1, h2, h3, h4, h5, h6 {\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n}\n\nh1 {font-size: 22px;margin-bottom: 10px;}\nh2 {font-size: 18px;margin-bottom: 10px;}\nh3 {font-size: 14px;margin-bottom: 10px;}\nh4 {font-size: 12px;margin-bottom: 10px;}\nh5 {font-size: 12px;margin-bottom: 10px;}\nh6 {font-size: 11px;margin-bottom: 10px;}\n\na {color: #FF7432;text-decoration: none;}\na.active {color: #d0d0d0;}\na:hover {text-decoration: underline;}\na.active:hover {text-decoration: none;}\n\n.pull-right {float: right;}\n.both {clear: both;}\n\np {margin-bottom: 10px;}\np:last-child {margin-bottom: 0;}\n\nhr {\n	height: 0;\n	border: 0;\n	border-bottom: 1px solid #444444;\n	margin: 10px 0;\n}\n.layout {\n	width: 1100px;\n	margin: auto;\n	position: relative;\n}\n.logo1 {\n	position: absolute;\n	left: 10px;\n	font-size: 40px;\n	top: 25px;\n	color: #ddd;\n	font-family: Tenor Sans, arial;\n}\n.logo2 {\n	position: absolute;\n	right: 10px;\n	font-size: 16px;\n	top: 28px;\n	color: #ddd;\n	font-family: Tenor Sans, arial;\n}\n.content {\n	position: absolute;\n	top: 100px;\n	left: 0;\n	right: 0;\n	background: #000;\n}\n.sidebar {\n	width: 240px;\n	float: left;\n}\n.main {\n	width: 855px;\n	float: right;\n}\n.block {\n	margin-top: 5px;\n	clear: both;\n}\n.block .head {\n	padding: 0 10px;\n	font-size: 16px;\n	line-height: 36px;\n	height: 40px;\n	background: #270909;\n	color: #d0d0d0;\n	border-bottom: 1px solid #000;\n	border-top: 4px solid #874020;\n	font-weight: normal;\n}\n.block .head2 {\n	background: #171718;\n	border-top: 4px solid #444;\n}\n.block .head3 {\n	background: #171718;\n	border-top: 0;\n	border-bottom: 0;\n	padding-top: 10px;\n	color: #979899;\n	line-height: 1;\n	height: auto;\n}\n.block .head3 a {\n	color: #979899;\n	display: block;\n	float: left;\n	padding: 10px;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n}\n.block .head3 a.active {\n	color: #FF7432;\n	background: #252528;\n}\n.block .head4 {\n	padding: 0;\n	height: auto;\n}\n.block .body {\n	padding: 10px;\n	background: #270909;\n}\n.block .body2 {\n	background: #171718;\n}\n.footer {\n	margin-top: 20px;\n	border-top: 1px solid #222;\n	padding: 10px;\n	text-align: center;\n}\n\n/*------------------------------------------\n	Таблицы (список игроков, военкомат и тд)\n------------------------------------------*/\n\n.grid-view {\n}\n.grid-view .items {\n	width: 100%;\n	font-size: 12px;\n}\n.grid-view .items thead {\n}\n.grid-view .items thead th {\n	text-align: left;\n	padding: 5px;\n	background: #270909;\n	border: 1px solid #171718;\n}\n.grid-view .items tbody td, .grid-view .items thead td {\n	text-align: left;\n	padding: 5px;\n	background: #242426;\n	border-bottom: 1px solid #171718;\n	border-right: 1px solid #171718;\n	border-left: 1px solid #171718;\n}\n.grid-view .summary {\n	text-align: right;\n	margin-bottom: 5px;\n}\n.grid-view input, .grid-view select {\n	border: 1px solid #444;\n	background: silver;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n	width: 100%;\n}\n\n/*------------------------------------------\n	Списки (новости и тд)\n------------------------------------------*/\n\n.list-view {\n	background: #171718;\n}\n.list-view .summary {\n	text-align: right;\n	margin-bottom: 5px;\n}\n.list-view .view {\n	margin-bottom: 10px;\n}\n.list-view .view:last-child {\n	margin-bottom: 0;\n}\n\n/*------------------------------------------\n	Подробные описания (информация об игроке и тд)\n------------------------------------------*/\n\ntable.detail-view .null {\n\n}\ntable.detail-view {\n    width: 100%;\n}\ntable.detail-view th, table.detail-view td {\n	vertical-align: top;\n	padding: 5px 15px;\n	background: #242426;\n	border-bottom: 1px solid #171718;\n}\ntable.detail-view th {\n	text-align: right;\n	width: 160px;\n	background: #270909;\n	border-right: 1px solid #171718;\n}\ntable.detail-view tr.odd {\n}\ntable.detail-view tr.even {\n}\ntable.detail-view tr.odd th {\n}\ntable.detail-view tr.even th {\n}\n\n/*------------------------------------------\n	Постраничная навигация\n------------------------------------------*/\n\n.pager {\n	margin-top: 10px !important;\n	text-align: right;\n	font-size: 12px;\n}\nul.yiiPager {\n    display: inline;\n}\nul.yiiPager li {\n    display: inline;\n}\nul.yiiPager a:link, ul.yiiPager a:visited {\n    border: 1px solid #979899;\n    padding: 1px 6px;\n    text-decoration: none;\n}\nul.yiiPager .page a {\n    font-weight: normal;\n}\nul.yiiPager a:hover {\n    border: 1px solid #FF7432;\n}\nul.yiiPager .selected a {\n    background: none repeat scroll 0 0 #591D1D;\n    color: #979899;\n}\nul.yiiPager .hidden a {\n    border: 1px solid #979899;\n    color: #979899;\n		cursor: default;\n}\nul.yiiPager .first, ul.yiiPager .last {\n    display: none;\n}\n\n/*------------------------------------------\n	Формы\n------------------------------------------*/\n\nform {\n	margin: 0;\n}\ndiv.form\n{\n	border: 1px solid #171718;\n	background: #242426;\n	padding: 10px;\n}\ndiv.form input,\ndiv.form textarea,\ndiv.form select\n{\n	border: 1px solid #444;\n	background: silver;\n	padding: 3px;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n	width: 200px;\n}\ndiv.form textarea\n{\n	width: 400px;\n	height: 100px;\n}\ndiv.form fieldset\n{\n	border: 1px solid #DDD;\n	padding: 10px;\n	margin: 0 0 10px 0;\n    -moz-border-radius:7px;\n}\ndiv.form label\n{\n	margin: 4px 0 0 0;\n	display: block;\n	width: 180px;\n	float: left;\n}\ndiv.form .row\n{\n	margin: 10px 0 0 0;\n	clear: both;\n}\ndiv.form .row:first-child\n{\n	margin: 0;\n}\ndiv.form .hint\n{\n	color: #999;\n	font-size: 0.9em;\n	margin-top: 2px;\n}\ndiv.form .note\n{\n	font-style: italic;\n}\ndiv.form span.required\n{\n	color: red;\n}\ndiv.form div.error label:first-child,\ndiv.form label.error,\ndiv.form span.error\n{\n	color: #C00;\n}\ndiv.form div.error input,\ndiv.form div.error textarea,\ndiv.form div.error select,\ndiv.form input.error,\ndiv.form textarea.error,\ndiv.form select.error\n{\n	background: silver;\n	border: 1px solid #C00;\n}\ndiv.form div.success input,\ndiv.form div.success textarea,\ndiv.form div.success select,\ndiv.form input.success,\ndiv.form textarea.success,\ndiv.form select.success\n{\n	background: #E6EFC2;\n	border-color: #C6D880;\n}\ndiv.form div.success label\n{\n	color: inherit;\n}\ndiv.form .errorSummary\n{\n	border: 2px solid #C00;\n	padding: 7px 7px 12px 7px;\n	margin: 0 0 20px 0;\n}\ndiv.form .errorMessage\n{\n	color: red;\n	font-size: 12px;\n	margin: 3px 0 0 0;\n}\ndiv.form .errorSummary p\n{\n	margin: 0;\n	padding: 5px;\n}\ndiv.form .errorSummary ul\n{\n	margin: 0;\n	padding: 0 0 0 20px;\n	list-style: square ;\n}\ndiv.form .buttons, div.form .hint, div.form .errorMessage {\n	padding-left: 180px;\n}\ndiv.form .buttons input {\n	width: auto;\n}\n.mce-tinymce.mce-container.mce-panel {\n	float: left !important;\n}\n\n/*------------------------------------------\n	Основное меню\n------------------------------------------*/\n\n.menu {\n}\n.menu ul {\n	background: url(\'../images/menu.png\') center 70%;\n	height: 40px;\n}\n.menu li a {\n	display: block;\n	padding: 0 10px;\n	float: left;\n	font-size: 16px;\n	line-height: 40px;\n	height: 40px;\n	border-right: 1px solid #000;\n}\n.menu li.pull-right a {\n	border-left: 1px solid #000;\n	border-right: 0;\n}\n.menu li.active a {\n	background: url(\'../images/menu.png\') center center;\n	color: #d0d0d0;\n}\n.menu li a:hover {\n	text-decoration: none;\n	background: url(\'../images/menu.png\') center 30%;\n}\n.menu .sub {\n	display: none;\n}\n\n/*------------------------------------------\n	Боковое меню\n------------------------------------------*/\n\n.block-menu li a {\n	text-decoration: none;\n	display: block;\n	margin: 0 -10px;\n	padding: 3px 10px;\n}\n.block-menu li.active a {\n	background: #441212;\n	color: #d0d0d0;\n}\n.block-menu li a:hover {\n	background: #591D1D;\n}\n.block-menu .sub {\n	display: none;\n}\n\n/*------------------------------------------\n	Новости\n------------------------------------------*/\n\n.news_one {\n	margin-bottom: 10px;\n	background: #272728;\n	padding: 10px;\n}\n.news_one:last-child {\n	margin-bottom: 0;\n}\n.news_one .time {\n	color: #666;\n	margin-right: 10px;\n}\n.news_one .title {\n	margin: 5px 0 0;\n}\n.news_one .text {\n	margin: 5px 0 0;\n	font-size: 12px;\n}\n.news_one .links {\n	margin: 5px 0 0;\n	font-size: 12px;\n}\n.news_one ul {\n	margin-left: 13px;\n	list-style: disc;\n}\n.news_one ol {\n	margin-left: 13px;\n	list-style: decimal;\n}\n\n/*------------------------------------------\n	Админка\n------------------------------------------*/\n\n.admin-link {\n	margin-top: 16px;\n	font-size: 16px;\n}\n.admin-link:first-child {\n	margin-top: 0;\n}\n\n/*------------------------------------------\n	Форум\n------------------------------------------*/\n\n.forum-grid .grid-view .items thead th, .forum-grid .grid-view .items thead td {\n	padding: 0;\n}\n.forum-groups .grid-view .items thead th, .forum-groups .grid-view .items thead td {\n	padding: 5px;\n}\n.forum-themes .grid-view .items thead th, .forum-themes .grid-view .items thead td {\n	padding: 5px;\n}\n.forum-grid .grid-view .items tbody td {\n	padding: 0;\n}\n.forum-groups .grid-view .items tbody td {\n	padding: 5px;\n}\n.forum-themes .grid-view .items tbody td {\n	padding: 5px;\n}\n.forum-grid .grid-view .items .nickname {\n	background: #270909;\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .role {\n	padding: 10px;\n}\n.forum-grid .grid-view .items td.empty {\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .time {\n	background: #270909;\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .time a {\n	display: inline-block;\n	margin-left: 8px;\n}\n.forum-grid .grid-view .items .message {\n	padding: 10px;\n}\n.forum-grid .grid-view .items .update {\n	padding: 10px 10px 0;\n	color: #666;\n}\n.forum-grid .grid-view .items .avatar {\n	margin: 10px 0 0 10px;\n}\n.forum-grid .grid-view .items .avatar img{\n	max-width: 150px !important;\n	max-height: 150px !important;\n}\n.forum-grid .grid-view .items .message img {\n	max-width: 630px !important;\n	height: auto !important;\n}\n\n\n/*------------------------------------------\n	Штаб\n------------------------------------------*/\n\nspan.clan-name {\n	font-size: 16px;\n	color: #d0d0d0;\n}\n.company-title {\n	margin: 15px 0 8px 0;\n	font-size: 16px;\n}\n\n/*------------------------------------------\n	Уведомления\n------------------------------------------*/\n\n.notice {\n	position: fixed;\n	background: #D1E5C3;\n	padding: 10px;\n	top: 10px;\n	right: 10px;\n	width: 300px;\n	border: 1px solid #8CC464;\n}\n.notice .text {\n	color: #444;\n}\n.notice .buttons {\n	margin: 10px 0 0;\n}\n\n/*------------------------------------------\n	Комментарии\n------------------------------------------*/\n\n.messages-grid .grid-view .items thead th, .messages-grid .grid-view .items thead td {\n	padding: 0;\n}\n.messages-grid .grid-view .items tbody td {\n	padding: 0;\n}\n.messages-grid .grid-view .items .nickname {\n	background: #270909;\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .role {\n	padding: 10px;\n}\n.messages-grid .grid-view .items td.empty {\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .time {\n	background: #270909;\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .message {\n	padding: 10px;\n}\n.messages-grid .grid-view .items .avatar {\n	margin: 10px 0 0 10px;\n}\n.messages-grid .grid-view .items .avatar img{\n	max-width: 150px !important;\n	max-height: 150px !important;\n}\n.messages-grid .grid-view .items .message img {\n	max-width: 630px !important;\n	height: auto !important;\n}\n\n.signature {\n    margin: 10px;\n    padding-top: 10px;\n    border-top: 1px solid #444;\n}\n.signature img {\n    background: none repeat scroll 0 0 #f0f0f0;\n}\n',	'machino',	'vinous',	'',	'',	'',	'',	1,	30),
(2,	'Сucumber',	'/*------------------------------------------\n	Сброс стилей\n------------------------------------------*/\n\nhtml, body, div, span, applet, object, iframe,\nh1, h2, h3, h4, h5, h6, p, blockquote, pre,\na, abbr, acronym, address, big, cite, code,\ndel, dfn, em, font, img, ins, kbd, q, s, samp,\nsmall, strike, strong, sub, sup, tt, var,\nb, u, i, center,\ndl, dt, dd, ol, ul, li,\nfieldset, form, label, legend,\ntable, caption, tbody, tfoot, thead, tr, th, td {\n	margin: 0;\n	padding: 0;\n	border: 0;\n	outline: 0;\n	font-size: 100%;\n	vertical-align: top;\n	background: transparent;\n}\nbody {\n	line-height: 1.3;\n}\nol, ul {\n	list-style: none;\n}\nblockquote, q {\n	quotes: none;\n}\n:focus {\n	outline: 0;\n}\nins {\n	text-decoration: none;\n}\ndel {\n	text-decoration: line-through;\n}\ntable {\n	border-collapse: collapse;\n	border-spacing: 0;\n}\nimg {max-width: 100%;}\n\n/*------------------------------------------\n	Общие стили\n------------------------------------------*/\n\nbody {\n	background: #f0f0f0 url(\'../images/bg4.jpg\') center -10px no-repeat;\n	font-family: arial;\n	font-size: 12px;\n	color: #444;\n}\ndiv, h1, h2, h3, h4, h5, h6 {\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n}\n\nh1 {font-size: 22px;margin-bottom: 10px;}\nh2 {font-size: 18px;margin-bottom: 10px;}\nh3 {font-size: 14px;margin-bottom: 10px;}\nh4 {font-size: 12px;margin-bottom: 10px;}\nh5 {font-size: 12px;margin-bottom: 10px;}\nh6 {font-size: 11px;margin-bottom: 10px;}\n\na {color: #89542E;text-decoration: none;}\na.active {color: #BF4F00;}\na:hover {text-decoration: underline;}\na.active:hover {text-decoration: none;}\n\n.pull-right {float: right;}\n.both {clear: both;}\n\np {margin-bottom: 10px;}\np:last-child {margin-bottom: 0;}\n\nhr {\n	height: 0;\n	border: 0;\n	border-bottom: 1px solid #444444;\n	margin: 10px 0;\n}\n.layout {\n	width: 1100px;\n	margin: auto;\n	position: relative;\n}\n.logo1 {\n	position: absolute;\n	left: 10px;\n	font-size: 40px;\n	top: 40px;\n	color: #4C590D;\n	font-family: Tenor Sans, arial;\n}\n.logo2 {\n	position: absolute;\n	left: 12px;\n	font-size: 16px;\n	top: 115px;\n	color: #444;\n	font-family: Tenor Sans, arial;\n}\n.content {\n	position: absolute;\n	top: 220px;\n	left: 0;\n	right: 0;\n	background: transparent;\n}\n.sidebar {\n	width: 240px;\n	float: left;\n}\n.main {\n	width: 855px;\n	float: right;\n}\n.block {\n	margin-top: 5px;\n	clear: both;\n}\n.block .head {\n	padding: 0 10px;\n	font-size: 16px;\n	line-height: 36px;\n	height: 40px;\n	background: #89542E;\n	color: #d0d0d0;\n	border-bottom: 0;\n	border-top: 0;\n	font-weight: normal;\n	border-radius: 4px 4px 0 0;\n}\n.block .head2 {\n	background: #4C590D;\n	border-top: 1px solid #444;\n	border-radius: 4px 4px 0 0;\n}\n.block .head3 {\n	background: #ACB584;\n	border-top: 0;\n	border-bottom: 0;\n	padding-top: 10px;\n	color: #979899;\n	line-height: 1;\n	height: auto;\n	border-radius: 0;\n}\n.block .head3 a {\n	color: #444;\n	display: block;\n	float: left;\n	padding: 10px;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n}\n.block .head3 a.active {\n	color: #444;\n	background: #9FAA6D;\n}\n.block .head4 {\n	padding: 0;\n	height: auto;\n}\n.block .body {\n	padding: 10px;\n	background: #C6B681;\n	border-radius: 0 0 4px 4px;\n}\n.block .body2 {\n	background: #B7BF93;\n	border-radius: 0 0 4px 4px;\n}\n.footer {\n	margin-top: 20px;\n	border-top: 1px solid #222;\n	padding: 10px;\n	text-align: center;\n}\n\n/*------------------------------------------\n	Таблицы (список игроков, военкомат и тд)\n------------------------------------------*/\n\n.grid-view {\n}\n.grid-view .items {\n	width: 100%;\n	font-size: 12px;\n}\n.grid-view .items thead {\n}\n.grid-view .items thead th {\n	text-align: left;\n	padding: 5px;\n	background: #4C590D;\n	border: 1px solid #B7BF93;\n	color: #b7bf93;\n}\n.grid-view .items thead th a {\n	color: #b7bf93;\n}\n.grid-view .items thead th a:hover {\n	color: #f0f0f0;\n}\n.grid-view .items tbody td, .grid-view .items thead td {\n	text-align: left;\n	padding: 5px;\n	background: #ACB584;\n	border-bottom: 1px solid #B7BF93;\n	border-right: 1px solid #B7BF93;\n	border-left: 1px solid #B7BF93;\n}\n.grid-view .summary {\n	text-align: right;\n	margin-bottom: 5px;\n}\n.grid-view input, .grid-view select {\n	border: 1px solid #9FAA6F;\n	background: #B7BF93;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n	width: 100%;\n}\n\n/*------------------------------------------\n	Списки (новости и тд)\n------------------------------------------*/\n\n.list-view {\n	background: #B7BF93;\n}\n.list-view .summary {\n	text-align: right;\n	margin-bottom: 5px;\n}\n.list-view .view {\n	margin-bottom: 10px;\n}\n.list-view .view:last-child {\n	margin-bottom: 0;\n}\n\n/*------------------------------------------\n	Подробные описания (информация об игроке и тд)\n------------------------------------------*/\n\ntable.detail-view .null {\n\n}\ntable.detail-view {\n    width: 100%;\n}\ntable.detail-view th, table.detail-view td {\n	vertical-align: top;\n	padding: 5px 15px;\n	background: #ACB584;\n	border-bottom: 1px solid #B7BF93;\n}\ntable.detail-view th {\n	text-align: right;\n	width: 160px;\n	background: #89542E;\n	border-right: 1px solid #B7BF93;\n	color: #d0d0d0;\n}\ntable.detail-view tr.odd {\n}\ntable.detail-view tr.even {\n}\ntable.detail-view tr.odd th {\n}\ntable.detail-view tr.even th {\n}\n\n/*------------------------------------------\n	Постраничная навигация\n------------------------------------------*/\n\n.pager {\n	margin-top: 10px !important;\n	text-align: right;\n	font-size: 12px;\n}\nul.yiiPager {\n    display: inline;\n}\nul.yiiPager li {\n    display: inline;\n}\nul.yiiPager a:link, ul.yiiPager a:visited {\n    border: 1px solid #979899;\n    padding: 1px 6px;\n    text-decoration: none;\n}\nul.yiiPager .page a {\n    font-weight: normal;\n}\nul.yiiPager a:hover {\n    border: 1px solid #FF7432;\n}\nul.yiiPager .selected a {\n    background: none repeat scroll 0 0 #591D1D;\n    color: #979899;\n}\nul.yiiPager .hidden a {\n    border: 1px solid #979899;\n    color: #979899;\n		cursor: default;\n}\nul.yiiPager .first, ul.yiiPager .last {\n    display: none;\n}\n\n/*------------------------------------------\n	Формы\n------------------------------------------*/\n\nform {\n	margin: 0;\n}\ndiv.form\n{\n	border: 1px solid #B7BF93;\n	background: #ACB584;\n	padding: 10px;\n}\ndiv.form input,\ndiv.form textarea,\ndiv.form select\n{\n	border: 1px solid #4C590D;\n	background: #f0f0f0;\n	padding: 3px;\n	box-sizing: border-box;\n	-moz-box-sizing: border-box;\n	-webkit-box-sizing: border-box;\n	width: 200px;\n}\ndiv.form textarea\n{\n	width: 400px;\n	height: 100px;\n}\ndiv.form fieldset\n{\n	border: 1px solid #DDD;\n	padding: 10px;\n	margin: 0 0 10px 0;\n    -moz-border-radius:7px;\n}\ndiv.form label\n{\n	margin: 4px 0 0 0;\n	display: block;\n	width: 180px;\n	float: left;\n}\ndiv.form .row\n{\n	margin: 10px 0 0 0;\n	clear: both;\n}\ndiv.form .row:first-child\n{\n	margin: 0;\n}\ndiv.form .hint\n{\n	color: #666;\n	font-size: 0.9em;\n	margin-top: 2px;\n}\ndiv.form .note\n{\n	font-style: italic;\n}\ndiv.form span.required\n{\n	color: red;\n}\ndiv.form div.error label:first-child,\ndiv.form label.error,\ndiv.form span.error\n{\n	color: #C00;\n}\ndiv.form div.error input,\ndiv.form div.error textarea,\ndiv.form div.error select,\ndiv.form input.error,\ndiv.form textarea.error,\ndiv.form select.error\n{\n	background: #fff0f0;\n	border: 1px solid #C00;\n}\ndiv.form div.success input,\ndiv.form div.success textarea,\ndiv.form div.success select,\ndiv.form input.success,\ndiv.form textarea.success,\ndiv.form select.success\n{\n	background: #E6EFC2;\n	border-color: #C6D880;\n}\ndiv.form div.success label\n{\n	color: inherit;\n}\ndiv.form .errorSummary\n{\n	border: 2px solid #C00;\n	padding: 7px 7px 12px 7px;\n	margin: 0 0 20px 0;\n}\ndiv.form .errorMessage\n{\n	color: red;\n	font-size: 12px;\n	margin: 3px 0 0 0;\n}\ndiv.form .errorSummary p\n{\n	margin: 0;\n	padding: 5px;\n}\ndiv.form .errorSummary ul\n{\n	margin: 0;\n	padding: 0 0 0 20px;\n	list-style: square ;\n}\ndiv.form .buttons, div.form .hint, div.form .errorMessage {\n	padding-left: 180px;\n}\ndiv.form .buttons input {\n	width: auto;\n}\n.mce-tinymce.mce-container.mce-panel {\n	float: left !important;\n}\n\n/*------------------------------------------\n	Основное меню\n------------------------------------------*/\n\n.menu {\n}\n.menu ul {\n	background: #4C590D;\n	height: 40px;\n	border-radius: 4px;\n}\n.menu li a {\n	display: block;\n	padding: 0 10px;\n	float: left;\n	font-size: 16px;\n	line-height: 40px;\n	height: 40px;\n	border-right: 1px solid #B7BF93;\n	color: #B7BF93;\n}\n.menu li.pull-right a {\n	border-left: 1px solid #B7BF93;\n	border-right: 0;\n	color: #B7BF93;\n}\n.menu li.active a {\n	background: #89542E;\n	color: #B7BF93;\n}\n.menu li.active:first-child a {\n	border-radius: 4px 0 0 4px;\n}\n.menu li a:hover {\n	text-decoration: none;\n	background: #89542E;\n}\n.menu li:first-child a:hover {\n	border-radius: 4px 0 0 4px;\n}\n.menu li.last a:hover {\n	border-radius: 0 4px 4px 0;\n}\n.menu .sub {\n	display: none;\n}\n\n/*------------------------------------------\n	Боковое меню\n------------------------------------------*/\n\n.block-menu li a {\n	text-decoration: none;\n	display: block;\n	margin: 0 -10px;\n	padding: 3px 10px;\n}\n.block-menu li.active a {\n	background: #DBC785;\n	color: #444;\n}\n.block-menu li a:hover {\n	background: #DBC785;\n}\n.block-menu .sub {\n	display: none;\n}\n\n/*------------------------------------------\n	Новости\n------------------------------------------*/\n\n.news_one {\n	margin-bottom: 10px;\n	background: #ACB584;\n	padding: 10px;\n}\n.news_one:last-child {\n	margin-bottom: 0;\n}\n.news_one .time {\n	color: #666;\n	margin-right: 10px;\n}\n.news_one .title {\n	margin: 5px 0 0;\n}\n.news_one .text {\n	margin: 5px 0 0;\n	font-size: 12px;\n}\n.news_one .links {\n	margin: 5px 0 0;\n	font-size: 12px;\n}\n.news_one ul {\n	margin-left: 13px;\n	list-style: disc;\n}\n.news_one ol {\n	margin-left: 13px;\n	list-style: decimal;\n}\n\n/*------------------------------------------\n	Админка\n------------------------------------------*/\n\n.admin-link {\n	margin-top: 16px;\n	font-size: 16px;\n}\n.admin-link:first-child {\n	margin-top: 0;\n}\n\n/*------------------------------------------\n	Форум\n------------------------------------------*/\n\n.forum-grid .grid-view .items thead th, .forum-grid .grid-view .items thead td {\n	padding: 0;\n}\n.forum-groups .grid-view .items thead th, .forum-groups .grid-view .items thead td {\n	padding: 5px;\n}\n.forum-themes .grid-view .items thead th, .forum-themes .grid-view .items thead td {\n	padding: 5px;\n}\n.forum-grid .grid-view .items tbody td {\n	padding: 0;\n}\n.forum-groups .grid-view .items tbody td {\n	padding: 5px;\n}\n.forum-themes .grid-view .items tbody td {\n	padding: 5px;\n}\n.forum-grid .grid-view .items .nickname {\n	background: #89542E;\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .nickname a {\n	color: #d0d0d0;\n}\n.forum-grid .grid-view .items .role {\n	padding: 10px;\n}\n.forum-grid .grid-view .items td.empty {\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .time {\n	background: #89542E;\n	padding: 5px 10px;\n}\n.forum-grid .grid-view .items .time a {\n	color: #d0d0d0;\n	display: inline-block;\n	margin-left: 8px;\n}\n.forum-grid .grid-view .items .message {\n	padding: 10px;\n}\n.forum-grid .grid-view .items .update {\n	padding: 10px 10px 0;\n	color: #666;\n}\n.forum-grid .grid-view .items .avatar {\n	margin: 10px 0 0 10px;\n}\n.forum-grid .grid-view .items .avatar img{\n	max-width: 150px !important;\n	max-height: 150px !important;	\n}\n.forum-grid .grid-view .items .message img {\n	max-width: 630px !important;\n	height: auto !important;\n}\n\n\n/*------------------------------------------\n	Штаб\n------------------------------------------*/\n\nspan.clan-name {\n	font-size: 16px;\n	color: #4C590D;\n}\n.company-title {\n	margin: 15px 0 8px 0;\n	font-size: 16px;\n}\n\n/*------------------------------------------\n	Уведомления\n------------------------------------------*/\n\n.notice {\n	position: fixed;\n	background: #D1E5C3;\n	padding: 10px;\n	top: 10px;\n	right: 10px;\n	width: 300px;\n	border: 1px solid #8CC464;\n}\n.notice .text {\n	color: #444;\n}\n.notice .buttons {\n	margin: 10px 0 0;\n}\n\n/*------------------------------------------\n	Комментарии\n------------------------------------------*/\n\n.messages-grid .grid-view .items thead th, .messages-grid .grid-view .items thead td {\n	padding: 0;\n}\n.messages-grid .grid-view .items tbody td {\n	padding: 0;\n}\n.messages-grid .grid-view .items .nickname {\n	background: #89542E;\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .nickname a {\n	color: #d0d0d0;\n}\n.messages-grid .grid-view .items .role {\n	padding: 10px;\n}\n.messages-grid .grid-view .items td.empty {\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .time {\n	background: #89542E;\n	padding: 5px 10px;\n}\n.messages-grid .grid-view .items .time a {\n	color: #d0d0d0;\n}\n.messages-grid .grid-view .items .message {\n	padding: 10px;\n}\n.messages-grid .grid-view .items .avatar {\n	margin: 10px 0 0 10px;\n}\n.messages-grid .grid-view .items .avatar img{\n	max-width: 150px !important;\n	max-height: 150px !important;	\n}\n.messages-grid .grid-view .items .message img {\n	max-width: 630px !important;\n	height: auto !important;\n}\n\n.signature {\n    margin: 10px;\n    padding-top: 10px;\n    border-top: 1px solid #B7BF93;\n}\n.signature img {\n    background: none repeat scroll 0 0 #f0f0f0;\n}\n\n',	'machino',	'cucumber',	'',	'',	'',	'',	1,	20),
(3,	'Whitelog',	'',	'looney',	'whitelog',	'',	'',	'',	'',	1,	48),
(4,	'Skywarrior',	'',	'looney',	'skywarrior',	'',	'',	'',	'',	1,	49),
(5,	'Goliath',	'',	'clarity',	'goliath',	'',	'',	'',	'',	1,	43),
(6,	'Marron',	'',	'clarity',	'marron',	'',	'',	'',	'',	1,	42),
(7,	'Phoenix',	'',	'clarity',	'phoenix',	'',	'',	'',	'',	1,	44),
(8,	'Dimension',	'',	'clarity',	'dimension',	'',	'',	'',	'',	1,	47),
(9,	'Cooper',	'',	'clarity',	'cooper',	'',	'',	'',	'',	0,	46),
(10,	'Blackfyre',	'',	'clarity',	'blackfyre',	'',	'',	'',	'',	0,	45),
(11,	'Empire',	'',	'clarity',	'empire',	'',	'',	'',	'',	1,	41);

DROP TABLE IF EXISTS `tanks`;
CREATE TABLE `tanks` (
  `id` int(11) NOT NULL COMMENT ' 	  Идентификатор техники',
  `level` int(11) NOT NULL COMMENT 'Уровень',
  `nation` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Нация',
  `nation_i18n` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Локализованное поле nation',
  `is_premium` int(1) NOT NULL COMMENT 'Премиум техника',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `name_i18n` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Локализованное поле name',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тип',
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Картинка',
  `weight` float(5,3) NOT NULL DEFAULT '0.000' COMMENT 'Значимость',
  `short_name_i18n` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Краткое название',
  PRIMARY KEY (`id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Техника';


DROP TABLE IF EXISTS `tokens`;
CREATE TABLE `tokens` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Токен',
  `time` int(11) NOT NULL COMMENT 'Время',
  `account_id` bigint(20) NOT NULL COMMENT 'Аккаунт',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Токены авторизации';


DROP TABLE IF EXISTS `ts_servers`;
CREATE TABLE `ts_servers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `server_id` int(11) unsigned NOT NULL COMMENT 'ID реального сервера',
  `sid` int(11) unsigned NOT NULL COMMENT 'ID виртуального сервера',
  `port` varchar(5) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Порт',
  `alias` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Алиас',
  `time_created` int(11) unsigned NOT NULL COMMENT 'Дата создания',
  `time_down` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата отключения',
  `time_stat` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Время сбора статистики',
  `rate` float(8,2) unsigned NOT NULL COMMENT 'Цена слота',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `ip` (`server_id`),
  KEY `port` (`port`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='ТС серверы';


DROP TABLE IF EXISTS `ts_servers_bak`;
CREATE TABLE `ts_servers_bak` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(11) unsigned NOT NULL COMMENT 'Сайт',
  `server_id` int(11) unsigned NOT NULL COMMENT 'ID реального сервера',
  `sid` int(11) unsigned NOT NULL COMMENT 'ID виртуального сервера',
  `port` varchar(5) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Порт',
  `alias` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Алиас',
  `time_created` int(11) unsigned NOT NULL COMMENT 'Дата создания',
  `time_down` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Дата отключения',
  `time_stat` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Время сбора статистики',
  `rate` float(8,2) unsigned NOT NULL COMMENT 'Цена слота',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `ip` (`server_id`),
  KEY `port` (`port`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='ТС серверы';


DROP TABLE IF EXISTS `ts_stat`;
CREATE TABLE `ts_stat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_id` int(10) unsigned NOT NULL COMMENT 'Сайт',
  `server_id` int(10) unsigned NOT NULL COMMENT 'Сервер',
  `time` int(10) unsigned NOT NULL COMMENT 'Дата',
  `rate` float(8,2) unsigned NOT NULL COMMENT 'Цена слота',
  `amount` float(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Сумма',
  `online` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Онлайн',
  `processed` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Обработано',
  PRIMARY KEY (`id`),
  KEY `server_id` (`server_id`),
  KEY `time` (`time`),
  KEY `processed` (`processed`),
  KEY `site_id` (`site_id`),
  KEY `amount` (`amount`),
  KEY `online` (`online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Статистика серверов ТС';


DROP TABLE IF EXISTS `widgets`;
CREATE TABLE `widgets` (
  `name` varchar(64) NOT NULL COMMENT 'Аббревиатура',
  `description` varchar(255) NOT NULL COMMENT 'Описание',
  `params` text NOT NULL COMMENT 'Список параметров',
  `example` text NOT NULL COMMENT 'Пример использования',
  `premium` varchar(3) NOT NULL COMMENT 'Платный',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT 'Сортировка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Виджеты';

INSERT INTO `widgets` (`name`, `description`, `params`, `example`, `premium`, `order`) VALUES
('DOMAIN',	'Адрес сайта (доменное имя)',	'Нет',	'Наш сайт: {DOMAIN}',	'Нет',	0),
('SITE_NAME',	'Название сайта из настроек',	'Нет',	'<h1>{SITE_NAME}</h1>',	'Нет',	10),
('SLOGAN',	'Девиз сайта из настроек',	'Нет',	'<p>{SLOGAN}</p>',	'Нет',	0),
('MENU',	'Блок основного меню',	'Нет',	'<div class=\"menu_bottom\">\r\n{MENU}\r\n</div>',	'Нет',	30),
('MENU_BLOCK',	'Блок бокового меню',	'Нет',	'<div class=\"menu_sidebar\">\r\n{MENU_BLOCK}\r\n</div>',	'Нет',	40),
('STATIC',	'Блок, содержащий текст любой статической страницы',	'name - URL страницы из раздела консоли управления \"Контент - Статичные страницы\". Необязательный параметр. Значение по умолчанию: textonmain.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: заголовок указанной в параметре name страницы.',	'Для вывода на главную страницу блока с требованиями к вступающим в клан необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML главной страницы\" дописать виджет:\r\n\r\n{STATIC name=requirements title=\"Вступающим в наши ряды\"}\r\n\r\nВы можете создать любое количество статических страниц и вывести их в доступных областях.',	'Нет',	50),
('ADMIN_MENU',	'Блок меню администратора',	'Нет',	'<div class=\"menu_admin\">\r\n{ADMIN_MENU}\r\n</div>',	'Нет',	45),
('NEWS',	'Блок, содержащий список новостей из любой категории',	'ids - Список ID категорий из которых выводить новости. Категории должны быть разделены запятыми без пробелов. Необязательный параметр. По умолчанию выводятся новости из всех категорий.\r\n\r\ncnt - Количество выводимых на страницу новостей. Число от 1 до 50. Необязательный параметр. Значение по умолчанию: 10.\r\n\r\ntype - Тип блока. default или mini. default - новости выводятся с заголовком, текстом новости и картинкой. mini - только заголовок новости. Необязательный параметр. Значение по умолчанию: default.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: Новости.',	'Для вывода на главную страницу блока со всеми новостями необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML главной страницы\" дописать виджет:\r\n\r\n{NEWS}\r\n\r\nДля вывода в боковую колонку трех последних новостей из основной категории необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{NEWS ids=1 cnt=3 type=mini title=\"Последние новости\"}\r\n\r\nВывод новостей из произвольных категорий:\r\n\r\n{NEWS ids=22,25}',	'Нет',	60),
('VK',	'Блок ВКонтакте',	'id - ID группы ВК. Число. Не путайте с аббревиатурой группы. Необязательный параметр. По умолчанию используется ID из настроек сайта.\r\n\r\nwidth - Ширина блока в пикселях. Число. Необязательный параметр. Значение по умолчанию: 240.\r\n\r\nheight - Высота блока в пикселях. Число. Необязательный параметр. Значение по умолчанию: 400.\r\n\r\ncolor1 - Цвет фона виджета ВК. Значение цвета в шестнадцатеричной системе. Необязательный параметр. По умолчанию используется цвет из настроек сайта.\r\n\r\ncolor2 - Цвет текста виджета ВК. Значение цвета в шестнадцатеричной системе. Необязательный параметр. По умолчанию используется цвет из настроек сайта.\r\n\r\ncolor3 - Цвет фона заголовка виджета ВК. Значение цвета в шестнадцатеричной системе. Необязательный параметр. По умолчанию используется цвет из настроек сайта.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: ВКонтакте.',	'Для вывода в боковую колонку виджета ВК для группы с идентификатором 123 необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{VK id=123 height=500 color1=F700E2 title=\"Наша группа ВК\"}',	'Нет',	70),
('TWITCH',	'Блок Twitch',	'chan - Название канала twitch. Не путайте с адресом канала twitch. Необязательный параметр. По умолчанию используется канал из настроек сайта.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. По умолчанию используется заголовок из настроек сайта.',	'Для вывода на главную страницу стрима с канала, расположенного по адресу http://www.twitch.tv/wotpw, необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML главной страницы\" дописать виджет:\r\n\r\n{TWITCH chan=wotpw title=\"Канал WOT.PW\"}',	'Нет',	80),
('CHAT',	'Чат',	'height - Высота окна с сообщениями\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: Чат.',	'Для вывода в боковую колонку виджета чата высотой 200px необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{CHAT height=200}',	'Да',	90),
('ONLINE',	'Список пользователей онлайн',	'title - Заголовок блока. Необязательный параметр. Значение по умолчанию: Кто онлайн.',	'Для вывода в боковую колонку виджета необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{ONLINE}',	'Нет',	20),
('POLL',	'Опрос',	'id - Идентификатор опроса. Число. Обязательный параметр\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: Опросы.',	'Для вывода в боковую колонку виджета необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{POLL id=123}',	'Да',	100),
('THEMES',	'Активные темы с форума',	'cnt - Количество выводимых тем. Число от 1 до 50. Необязательный параметр. Значение по умолчанию: 5.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: Активные темы.\r\n\r\nВНИМАНИЕ! Виджет кешируется при выводе. При смене параметров виджета или темы сайта необходимо написать любое сообщение на форуме для сброса кеша.',	'Для вывода в боковую колонку трех активных тем необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{THEMES cnt=3 title=\"Активные темы\"}',	'Нет',	60),
('DONATE',	'Виджет пополнения баланса сайта',	'balance - Показывать баланс сайта в виджете. Число. 1 - показывать, 0 - не показывать. Необязательный параметр. Значение по умолчанию: 1.\r\n\r\ntitle - Заголовок блока. Необязательный параметр. Значение по умолчанию: Помощь сайту.',	'Для вывода в боковую колонку виджета пополнения баланса необходимо в раздел консоли управления \"Внешний вид - Дизайн сайта - HTML боковой колонки\" дописать виджет:\r\n\r\n{DONATE}\r\n\r\nИзменить заголовок виджета и спрятать баланс:\r\n\r\n{DONATE balance=0 title=\"Скинуться на Тимспик\"}',	'Нет',	110);

-- 2019-12-14 09:40:41
